package com.visiontune.app

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class AppListAdapter(
    private val context: Context,
    private val apps: List<ActivityInfo>,
    private val pm: PackageManager,
    private val onClick: (ActivityInfo) -> Unit
) : BaseAdapter() {

    override fun getCount() = apps.size
    override fun getItem(position: Int): ActivityInfo = apps[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_app, parent, false)
        val info = apps[position]
        view.findViewById<TextView>(R.id.appLabel).text = info.loadLabel(pm)
        view.findViewById<TextView>(R.id.appPackage).text = info.packageName
        view.findViewById<ImageView>(R.id.appIcon).setImageDrawable(info.loadIcon(pm))
        view.setOnClickListener { onClick(info) }
        return view
    }
}
