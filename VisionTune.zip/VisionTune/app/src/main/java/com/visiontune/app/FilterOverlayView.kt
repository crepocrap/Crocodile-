package com.visiontune.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

/**
 * HONEST NOTE ON HOW THIS ACTUALLY WORKS:
 *
 * This view lives in its own transparent overlay WINDOW, stacked on top of
 * whatever app is in front. Android's public windowing API only lets a
 * third-party overlay window blend into the screen with normal alpha
 * ("SRC_OVER") compositing - there is no public API that lets an app tell
 * the system compositor to run a custom saturation/contrast matrix against
 * the window(s) underneath it. So every effect below is built honestly out
 * of plain semi-transparent layers, which is the only thing that is real:
 *
 *  - exposure: a black or white layer darkens/brightens everything under
 *    it. This is a standard, well-known technique (same idea as apps like
 *    Twilight/Night filters) and costs ~0 extra GPU time.
 *  - saturation: can only be REDUCED, never boosted. A neutral-gray layer
 *    pulls every color toward gray, which reads as "less vivid". A boost
 *    is not possible this way because this view never sees the game's
 *    actual pixels to amplify - that would require capturing the frame
 *    (MediaProjection), which does cost real performance.
 *  - shadow: a radial dark vignette toward the edges.
 *  - clarity ("Clarity Boost"): a very subtle contrast/vignette illusion,
 *    the same trick "Clarity"/"Dehaze" sliders use in photo apps. It is
 *    NOT real sharpening or resolution upscaling - it cannot be, from an
 *    overlay that never touches the source pixels. It is disclosed as an
 *    illusion on purpose instead of being branded as something it isn't.
 */
class FilterOverlayView(context: Context) : View(context) {

    var settings: FilterSettings = FilterSettings()
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (settings.saturation < 100) {
            val amount = (100 - settings.saturation) / 100f
            paint.color = Color.GRAY
            paint.alpha = (amount * 140).toInt().coerceIn(0, 140)
            canvas.drawRect(0f, 0f, w, h, paint)
        }

        if (settings.exposure != 0) {
            val amount = kotlin.math.abs(settings.exposure) / 100f
            paint.color = if (settings.exposure < 0) Color.BLACK else Color.WHITE
            paint.alpha = (amount * 130).toInt().coerceIn(0, 130)
            canvas.drawRect(0f, 0f, w, h, paint)
        }

        if (settings.shadow > 0) {
            val amount = settings.shadow / 100f
            val vignette = Paint().apply {
                shader = RadialGradient(
                    w / 2f, h / 2f,
                    maxOf(w, h) * 0.75f,
                    Color.TRANSPARENT,
                    Color.argb((amount * 170).toInt().coerceIn(0, 170), 0, 0, 0),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, w, h, vignette)
        }

        if (settings.clarity > 0) {
            val amount = settings.clarity / 100f
            val illusion = Paint().apply {
                shader = RadialGradient(
                    w / 2f, h / 2f,
                    maxOf(w, h) * 0.55f,
                    Color.TRANSPARENT,
                    Color.argb((amount * 35).toInt().coerceIn(0, 35), 0, 0, 0),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, w, h, illusion)
        }
    }
}
