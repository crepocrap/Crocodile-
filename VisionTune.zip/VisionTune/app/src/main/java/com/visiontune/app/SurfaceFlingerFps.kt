package com.visiontune.app

/**
 * Real FPS for apps that `dumpsys gfxinfo <pkg> framestats` can never see.
 *
 * `gfxinfo`/`framestats` is populated by Android's HWUI pipeline, which
 * only tracks View-based rendering (normal Activity layouts). Almost every
 * 3D game - Tomb Raider included - draws through a SurfaceView/GLSurfaceView
 * (or Vulkan) straight to its own SurfaceFlinger layer, completely
 * bypassing HWUI. For those apps `framestats` legitimately stays empty
 * forever; that's not a bug in FrameStatsParser, it's a different pipeline.
 *
 * SurfaceFlinger itself still logs real present timestamps per layer
 * though (`dumpsys SurfaceFlinger --latency <layer>`), and that log does
 * include SurfaceView/GL layers. This reads that instead, as a fallback
 * for exactly the apps gfxinfo can't cover.
 *
 * Known limit, stated plainly: this legacy `--latency` interface isn't
 * guaranteed on every OEM/Android version - if a device's SurfaceFlinger
 * doesn't support it, this returns null and the overlay falls back to the
 * "waiting for frame data" message, same as before.
 */
object SurfaceFlingerFps {

    /** Finds the SurfaceFlinger layer backing the target app's visible
     *  surface. Prefers an actual SurfaceView/GL layer over the Activity's
     *  own (mostly idle) decor layer, since the SurfaceView layer is the
     *  one that updates every rendered frame for a game. */
    fun findLayerName(targetPackage: String): String? {
        val list = ShizukuBridge.runShellCommand("dumpsys", "SurfaceFlinger", "--list") ?: return null
        val candidates = list.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && it.contains(targetPackage) }
            .toList()
        return candidates.firstOrNull { it.contains("SurfaceView", ignoreCase = true) }
            ?: candidates.firstOrNull()
    }

    /** Parses `dumpsys SurfaceFlinger --latency <layer>` output.
     *  First line: refresh period in nanoseconds (ignored here, we derive
     *  FPS from real deltas instead). Each following line: desired /
     *  actual / ready present timestamps in nanoseconds, tab-separated.
     *  A timestamp of 0 means "not yet presented" and is skipped. */
    fun parse(raw: String): FrameStats? {
        val lines = raw.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (lines.size < 3) return null

        val actualTimes = mutableListOf<Long>()
        for (line in lines.drop(1)) {
            val cols = line.split(Regex("\\s+"))
            if (cols.size < 2) continue
            val actual = cols[1].toLongOrNull() ?: continue
            if (actual <= 0L || actual == Long.MAX_VALUE) continue
            actualTimes.add(actual)
        }
        if (actualTimes.size < 2) return null
        actualTimes.sort()

        val deltas = actualTimes.zipWithNext { a, b -> b - a }.filter { it > 0 }
        if (deltas.isEmpty()) return null

        val avgDeltaNs = deltas.average()
        val fps = 1_000_000_000.0 / avgDeltaNs

        // Same "late frame" idea gfxinfo uses: a frame that took notably
        // longer than the typical gap counts as janky.
        val sortedDeltas = deltas.sorted()
        val medianNs = sortedDeltas[sortedDeltas.size / 2].toDouble()
        val jankCount = deltas.count { it > medianNs * 1.5 }
        val jankPercent = 100.0 * jankCount / deltas.size

        return FrameStats(fps = fps, jankPercent = jankPercent, sampleCount = deltas.size)
    }
}
